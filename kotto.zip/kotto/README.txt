kotto: A Mystical Guessing Game

"A simple game. Deceptively simple." — kotto

================================================================================

WHAT IS THIS?

You're walking down a quiet street. Maybe it's midnight. Maybe it's dusk. 
Maybe you've made some questionable life choices that led you here.

Then you meet kotto.

kotto is a cat. But not just any cat. kotto is a cosmic entity wrapped in fur,
a feline oracle with opinions, a small god with a gambling problem. And tonight,
kotto wants to play a game.

The rules are simple: Guess a number between 1 and 10.

The stakes are not.

================================================================================

HOW TO PLAY

1. Run the app
2. Read what kotto tells you (he gets upset if you skip)
3. Guess a number between 1 and 10
4. Experience one of two outcomes:
   - VICTORY: kotto grants you a wish (terms and conditions apply)
   - DEFEAT: Your terminal closes and kotto judges you from the void

================================================================================

FEATURES

FOUR PERSONALITIES
Every encounter, kotto manifests differently:
  - Theatrical: Dramatic, grandiose, probably practicing for a one-cat show
  - Cryptic: Speaks in riddles, enjoys your confusion
  - Playful: Excited! Enthusiastic! Possibly unhinged!
  - Ominous: You will remember this night. You will remember.

FIVE MYSTICAL LOCATIONS
  - Street: Classic. Streetlights. Existential dread.
  - Park: Misty trees. Ancient vibes. kotto on a bench.
  - Alley: Dark, narrow, probably smells like rain and regret.
  - Rooftop: kotto perches above the city like a tiny, judgmental gargoyle.
  - Cemetery: Stone angels. Marble monuments. A cat who understands mortality.

THE HINT SYSTEM (Maybe)
kotto might give you a hint. Or he might lie. Or speak in riddles.
  - 15% chance: Actual helpful hint (higher or lower)
  - 10% chance: Cryptic riddle that may or may not help
  - 5% chance: Straight up lies to you
  - 70% chance: No hint. Suffer.

ATMOSPHERIC STORYTELLING
  - Randomized dialogue every playthrough
  - Dynamic color-coded text (kotto is blue when calm, red when displeased)
  - Typewriter effect because kotto values presentation
  - Over 100+ unique lines of dialogue
  - Easter egg whispers if you win (sometimes kotto isn't quite done with you)

================================================================================

GAMEPLAY TIPS

DO:
  - Take your time reading
  - Press Enter thoughtfully
  - Choose your number wisely
  - Accept your fate with dignity

DON'T:
  - Skip kotto's dialogue (rude)
  - Enter anything except numbers 1-10 (kotto has no patience for this)
  - Guess wrong (self-explanatory)
  - Question the logic of a mystical cat (it won't help)

================================================================================

FAQ

Q: Is this game fair?
A: Define "fair." kotto operates on cosmic principles beyond your understanding.

Q: What happens if I lose?
A: Your terminal session ends. kotto vanishes. You sit in silence, reflecting 
   on your choices.

Q: Can I play again after losing?
A: Yes. kotto is infinite. kotto is patient. kotto always comes back.

Q: What if I want to quit?
A: There is no quit. Only win or lose. kotto didn't write a quit function.

Q: Is kotto real?
A: Have you met kotto? Then you tell me.

Q: Can I pet kotto?
A: The game does not support this feature. Also, kotto would probably not 
   allow it.

Q: What's the actual probability of winning?
A: 10%, assuming you enter a valid number. kotto thinks those are good odds. 
   You probably don't.

Q: Did kotto approve this README?
A: kotto rarely approves anything. But he tolerated it.

================================================================================

THE PHILOSOPHY OF kotto

From kotto's unpublished manifesto, "On Numbers and Consequence":

"Humans overthink. A number is a number. The universe whispers the answer. 
You need only listen. Or guess correctly. Preferably both."

"Failure is a teacher. Success is a surprise. I am neither. I am kotto."

"Between 1 and 10 lies infinity. You just have to find the right infinity."

"The game is not about the number. It is about whether you deserve the number."

================================================================================

KNOWN ISSUES

- Issue: Game ends when you lose
  Status: Not a bug. This is intentional. kotto has spoken.

- Issue: kotto sometimes gives false hints
  Status: Working as intended. Life is not fair. Neither is kotto.

- Issue: No save feature
  Status: Each encounter with kotto is unique. The moment cannot be saved. 
          Only experienced.

- Issue: kotto's personality changes between games
  Status: kotto contains multitudes.

================================================================================

TESTIMONIALS

"I guessed wrong. I didn't even get to see my wish." 
— Anonymous Player

"10/10 would get judged by a cat again" 
— Lucky Winner

"Is... is this a therapy session disguised as a game?" 
— Confused Player

"I won and asked for infinite wishes. kotto said 'Granted' and left. I don't 
know if it worked." 
— Optimistic Player

"HISSSSSSSSSSSSSS" 
— kotto (regarding a particularly bad guess)

================================================================================

FINAL WORDS

Remember: kotto is not just a game. kotto is an experience. A trial. A cosmic 
test of intuition and nerve.

Will you guess correctly?
Will you earn your reward?
Will you walk away changed?
Or will your terminal close in a blaze of rage-text?

There's only one way to find out.

Run: kotto.exe

The cat is waiting.


"We may meet again, if fate permits." — kotto


================================================================================

APPENDIX: kotto's FAVORITE NUMBERS

kotto has been asked to share his favorite numbers for educational purposes.

He declined.

"That would ruin the game," he said.

Fair enough, kotto. Fair enough.